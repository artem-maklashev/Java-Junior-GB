package ru.geekbrains.lesson1.task2;

/**
 * Блокнот
 */
public class Notebook implements Thing {
    @Override
    public String getName() {
        return "Блокнот";
    }
}

