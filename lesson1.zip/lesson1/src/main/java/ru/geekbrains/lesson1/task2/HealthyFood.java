package ru.geekbrains.lesson1.task2;

/**
 * Здоровая еда
 */
public interface HealthyFood extends Food{
}
