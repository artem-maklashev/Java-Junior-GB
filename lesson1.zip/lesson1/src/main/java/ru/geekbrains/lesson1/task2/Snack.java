package ru.geekbrains.lesson1.task2;

/**
 * Снек (легкая закуска)
 */
public interface Snack extends Food {
}

