package ru.geekbrains.lesson1.task2;

/**
 * Полуфабрикат
 */
public interface SemiFinishedFood extends Food{
}

