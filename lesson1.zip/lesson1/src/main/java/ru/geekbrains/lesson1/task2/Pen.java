package ru.geekbrains.lesson1.task2;

/**
 * Ручка
 */
public class Pen implements Thing {
    @Override
    public String getName() {
        return "Ручка";
    }
}