package ru.geekbrains.lesson1.task2;

/**
 * Вещь
 */
public interface Thing {

    /**
     * Получить наименование вещи
     * @return наименование вещи
     */
    String getName();

}
